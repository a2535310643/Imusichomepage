
#Reference:https://www.geeksforgeeks.org/how-to-import-a-csv-file-into-a-sqlite-database-table-using-python/

import csv
import sqlite3


def fix_genres():
    pass; 

# Connecting to the using database
connection = sqlite3.connect('iMusic.db')
 
cursor = connection.cursor()
 

 

delete_table = "DELETE FROM Genre"
 

cursor.execute(delete_table)
 

file = open('genres.csv')
reader=csv.reader(file)
for u in file:
    print(u)

file = open('genres.csv')
next(file)
 

contents = csv.reader(file)
 

insert_records = "INSERT INTO Genre (GenreId, Name) VALUES(?, ?)"
 

cursor.executemany(insert_records, contents)
 

select_all = "SELECT * FROM Genre"
rows = cursor.execute(select_all).fetchall()
 

for r in rows:
    print(r)
 

connection.commit()
 

connection.close()



if __name__ == '__main__':
    fix_genres()
