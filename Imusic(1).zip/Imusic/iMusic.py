from flask import Flask, request, redirect, render_template, url_for
import sqlite3

app = Flask(__name__)


# I did not write this function. It is from:
# https://stackoverflow.com/questions/354038/how-do-i-check-if-a-string-represents-a-number-float-or-int
def is_number(s):
    """
    Check if a string is a number (regardless of it being an int, long, float or complex number)
    :param s: string The string to check if it is a number
    :return: True if string is a number, False otherwise
    """
    try:
        complex(s)
    except ValueError:
        return False
    return True

def is_integer(s):
    """
    Check if a string is an integer
    :param s: string The string to check if it is an integer
    :return: True if string is an integer, False otherwise
    """
    try:
        int(s)
    except ValueError:
        return False
    return True
    
def string_to_int(s):
    """
    Convert a string to an integer
    :param s: string The string to convert to an int
    :return: int The int value of the string
    """
    if is_number(s):
        return int(s)
    else:
        return s

def string_length(s):
    """
    Get the length of a string
    :param s: string The string to get the length of
    :return: int The length of the string
    """
    return len(s)




@app.route('/')
def index():
    return render_template('index.html')


@app.route('/statistics/')
def get_data():
    con = sqlite3.connect("iMusic.db")
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    # Here we say - execute this SQL query 
    #cur.execute(".open people.db")
    cur.execute("""SELECT UnitPrice AS Price, Count(TrackId) AS Tracks,Count(DISTINCT AlbumId) AS Albums,Count(DISTINCT ArtistId) as Artists,Sum(Milliseconds) AS Duration, (Count(TrackId)*UnitPrice) AS TotalValue From(SELECT UnitPrice,TrackId,Track.AlbumId,ArtistId,Milliseconds FROM Track left join Album on Track.AlbumId=Album.AlbumId)group by UnitPrice  
        UNION SELECT "Total" as "Total",COUNT(DISTINCT Track.TrackId),COUNT(DISTINCT Track.AlbumId),Count(DISTINCT ArtistId),Sum(Milliseconds),SUM(DISTINCT TotalValue) FROM 
        (Track left join Album  on Track.AlbumId=Album.AlbumId),
        (SELECT UnitPrice AS Price, Count(TrackId) AS Tracks,Count(DISTINCT AlbumId) AS Albums,Count(DISTINCT ArtistId) as Artists,Sum(Milliseconds) AS Duration, (Count(TrackId)*UnitPrice) AS TotalValue From(SELECT UnitPrice,TrackId,Track.AlbumId,ArtistId,Milliseconds FROM Track left join Album on Track.AlbumId=Album.AlbumId)group by UnitPrice)
        order by UnitPrice asc""")
   


    # Fetch all the results from the above query. 
    # We may alternatively request a single - fetchone
    prices = cur.fetchall()
    return render_template('statistics.html',prices=prices)   

# You do not need to modify this function (list_album)
@app.route('/album/')
@app.route('/album/<album_id>')
def list_album(album_id=None):
    return render_template('error.html', messages=["Album listing is not implemented yet. Another developer is working on it."])

# === Do not modify or add code after this line ===


@app.route('/add/',methods=['POST','GET'])


@app.route('/add/',methods=['POST','GET'])
def add():
    if request.method=='GET':

            con = sqlite3.connect("iMusic.db")
            con.row_factory = sqlite3.Row
            cur =con.cursor()
            cur.execute("SELECT * FROM Album")
            album = cur.fetchall()
            cmr =con.cursor()
            cmr.execute("SELECT * FROM Genre")
            genre = cmr.fetchall()
            return render_template('add_track.html',albums=album,genres=genre)

    else:
     #POST
     return redirect(url_for('addtrack'))
    
@app.route('/add/track',methods=['POST','GET'])
def addtrack():
    TrackName=request.form.get('track_name')
    AlbumId=request.form.get('track_album')
    GenreId=request.form.get('track_genre')
    Composer=request.form.get('track_composer')
    Duration=request.form.get('track_duration')
    Price=request.form.get('track_price')
    con = sqlite3.connect("iMusic.db")
    con.row_factory = sqlite3.Row
    cur =con.cursor()
    cur.execute("SELECT * FROM Album")
    album = cur.fetchall()
    cmr =con.cursor()
    cmr.execute("SELECT * FROM Genre")
    genre = cmr.fetchall()

    if string_length(TrackName)==0:
        return render_template('error.html', messages=["Track name is empty"])
    elif string_length(TrackName)>200:
        return render_template('error.html', messages=["Track name is too long"])
    else:
        if string_length(AlbumId)==0:
            return render_template('error.html', messages=["Album ID is invalid"])
        elif not is_integer(AlbumId):
            return render_template('error.html', messages=["Album ID is invalid"])
        else:
            if string_length(GenreId)==0:
                return render_template('error.html', messages=["Genre ID is invalid"])
            elif not is_integer(GenreId):
                return render_template('error.html', messages=["Genre ID is invalid"])
            else:
                if string_length(Composer)>220:
                    return render_template('error.html', messages=["Composer name is too long"])
                else:
                    if string_length(Duration)==0:
                        return render_template('error.html', messages=["Duration is invalid"])
                    elif not is_number(Duration):
                        return render_template('error.html', messages=["Duration is invalid"])
                    else:
                        if string_to_int(Duration)<=0:
                           return render_template('error.html', messages=["Duration must be a positive number"])
                        else:
                            if string_length(Price)==0:
                                return render_template('error.html', messages=["Price is invalid"])
                            elif not is_number(Price):
                                return render_template('error.html', messages=["Price is invalid"])
                            elif float(Price)<0 or float(Price)>10:
                                return render_template('error.html', messages=["Price must be more than zero and less than or equal to 10"])
                            else:
                                with sqlite3.connect('iMusic1.db') as con2:
                                 cur1 =con2.cursor()
                                 cur1.execute("""
                                 INSERT INTO Track1 (Name, AlbumId, GenreId, Composer, Milliseconds, UnitPrice)
                                 VALUES (?, ?, ?, ?, ?, ?)
                                 """, (TrackName, AlbumId,GenreId,Composer,Duration,Price))
                                 con2.commit()
                                return redirect(url_for('index'))

def main():
    app.run(debug=True, port=5000)

if __name__ == "__main__":
    main()
